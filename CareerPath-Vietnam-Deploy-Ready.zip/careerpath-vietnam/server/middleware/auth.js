import jwt from 'jsonwebtoken';
export function requireAuth(req,res,next){
  const token=req.cookies?.cp_token;
  if(!token)return res.status(401).json({error:'Vui lòng đăng nhập.'});
  try{const payload=jwt.verify(token,process.env.JWT_SECRET);req.user={id:payload.sub};next();}
  catch{return res.status(401).json({error:'Phiên đăng nhập hết hạn.'});}
}
